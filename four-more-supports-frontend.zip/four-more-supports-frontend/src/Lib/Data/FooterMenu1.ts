const FooterMenu1 = [
    {
        name: "Home",
        path: "/",
    },
    {
        name: "NDIS Support Services",
        path: "/",
    },
    {
        name: "About FMS",
        path: "/",
    },
    {
        name: "NDIS",
        path: "/",
    },
    {
        name: "Blogs",
        path: "/",
    },
    {
        name: "Contact us",
        path: "/",
    },
    {
        name: "Schedule of Supports",
        path: "/",
    },
];
const FooterMenu2 = [
    {
        name: "Terms of Use",
        path: "/",
    },
    {
        name: "Privacy Policy",
        path: "/",
    },
    {
        name: "Commplaints",
        path: "/",
    },
];
export const FooterMenu = {
    FooterMenu1,
    FooterMenu2,
};
