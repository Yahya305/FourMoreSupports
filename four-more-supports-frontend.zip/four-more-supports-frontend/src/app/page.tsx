import Footer from "@/Components/Footer";
import Header from "@/Components/Header";

export default function Home() {
    return (
        <main>
            <Footer />
            <Header />
        </main>
    );
}
